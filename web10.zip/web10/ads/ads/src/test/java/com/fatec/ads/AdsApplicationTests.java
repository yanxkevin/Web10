package com.fatec.ads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdsApplicationTests {

	@Test
	void contextLoads() {
	}

}
